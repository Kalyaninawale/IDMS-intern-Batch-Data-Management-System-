package com.example.IDMS.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import com.example.IDMS.dto.BatchDTO;
import com.example.IDMS.dto.InternIdListDTO;
import com.example.IDMS.service.BatchService;

import java.util.List;

@RestController
@RequestMapping("/api/batches")
@RequiredArgsConstructor
public class BatchController {

    private final BatchService batchService;

    // ✅ Create new batch
    @PostMapping
    public BatchDTO createBatch(@RequestBody BatchDTO batchDTO) {
        return batchService.createBatch(batchDTO);
    }

    // ✅ Get all batches
    @GetMapping
    public List<BatchDTO> getAllBatches() {
        return batchService.getAllBatches();
    }

    // ✅ Get batch by ID
    @GetMapping("/{id}")
    public BatchDTO getBatchById(@PathVariable Long id) {
        return batchService.getBatchById(id);
    }

    // ✅ Update batch
    @PutMapping("/{id}")
    public BatchDTO updateBatch(@PathVariable Long id, @RequestBody BatchDTO batchDTO) {
        return batchService.updateBatch(id, batchDTO);
    }

    // ✅ Delete batch
    @DeleteMapping("/{id}")
    public void deleteBatch(@PathVariable Long id) {
        batchService.deleteBatch(id);
    }

    // ✅ Get batch details (interns inside batch, etc.)
    @GetMapping("/{id}/details")
    public BatchDTO getBatchDetails(@PathVariable Long id) {
        return batchService.getBatchById(id);
    }

    // ✅ Assign single intern to batch
    @PostMapping("/{batchId}/assign/{internId}")
    public BatchDTO assignInternToBatch(@PathVariable Long batchId, @PathVariable Long internId) {
        return batchService.assignInternToBatch(batchId, internId);
    }

    // ✅ Unassign single intern from batch
    @DeleteMapping("/{batchId}/unassign/{internId}")
    public BatchDTO unassignInternFromBatch(@PathVariable Long batchId, @PathVariable Long internId) {
        return batchService.unassignInternFromBatch(batchId, internId);
    }

    // ✅ Bulk assign interns to batch
    @PostMapping("/{batchId}/assign")
    public BatchDTO bulkAssignInterns(@PathVariable Long batchId, @RequestBody InternIdListDTO internIds) {
        return batchService.bulkAssignInterns(batchId, internIds);
    }

    // ✅ Bulk unassign interns from batch
    @DeleteMapping("/{batchId}/unassign")
    public BatchDTO bulkUnassignInterns(@PathVariable Long batchId, @RequestBody InternIdListDTO internIds) {
        return batchService.bulkUnassignInterns(batchId, internIds);
    }
}
