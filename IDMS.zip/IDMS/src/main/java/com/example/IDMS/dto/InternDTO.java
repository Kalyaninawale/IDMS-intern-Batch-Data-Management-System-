package com.example.IDMS.dto;


import lombok.*;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InternDTO {
	private Long id;
    private String name;
    private String email;
    private String internId;
    private LocalDate dateOfJoining;  // ✅ LocalDate instead of String
    private String idType;

    private Long batchId;
    private String batchName; // for frontend display
}
