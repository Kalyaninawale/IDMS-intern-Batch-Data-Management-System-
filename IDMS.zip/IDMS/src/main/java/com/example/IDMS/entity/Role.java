package com.example.IDMS.entity;

public enum Role {
	 ADMIN,
	    USER
}
