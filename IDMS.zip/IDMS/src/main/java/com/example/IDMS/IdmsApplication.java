package com.example.IDMS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IdmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(IdmsApplication.class, args);
	}

	
	
}
