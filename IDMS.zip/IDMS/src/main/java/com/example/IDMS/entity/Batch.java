package com.example.IDMS.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "batch")
public class Batch {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "batch_name")
    private String batchName;
    public String getBatchName() { return batchName; }

    private LocalDate startDate;
    private LocalDate endDate;

    @OneToMany(mappedBy = "batch", cascade = CascadeType.ALL)
    private List<Intern> interns;
}
