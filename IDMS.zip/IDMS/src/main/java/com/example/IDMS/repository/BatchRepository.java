package com.example.IDMS.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.IDMS.entity.Batch;

public interface BatchRepository extends JpaRepository<Batch, Long> {
}
