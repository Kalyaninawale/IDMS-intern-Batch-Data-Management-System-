package com.example.IDMS.controller;

import com.example.IDMS.dto.InternDTO;
import com.example.IDMS.dto.InternDetailsDTO;
import com.example.IDMS.service.InternService;
import com.example.IDMS.util.IDGeneratorUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/interns")
@RequiredArgsConstructor
public class InternController {

    private final InternService internService;

    @PostMapping
    public InternDTO createIntern(@RequestBody InternDTO internDTO) {
        return internService.createIntern(internDTO);
    }

    @GetMapping
    public List<InternDTO> getAllInterns() {
        return internService.getAllInterns();
    }

    @GetMapping("/{id}")
    public InternDTO getInternById(@PathVariable Long id) {
        return internService.getInternById(id);
    }

    @PutMapping("/{id}")
    public InternDTO updateIntern(@PathVariable Long id, @RequestBody InternDTO internDTO) {
        return internService.updateIntern(id, internDTO);
    }

    @DeleteMapping("/{id}")
    public void deleteIntern(@PathVariable Long id) {
        internService.deleteIntern(id);
    }

    @GetMapping("/{id}/details")
    public InternDetailsDTO getInternDetails(@PathVariable Long id) {
        return internService.getInternDetails(id);
    }

    // 🔹 Preview next Intern ID
    @GetMapping("/preview-id")
    public String previewInternId(@RequestParam Long batchId,
                                  @RequestParam String idType,
                                  @RequestParam String dateOfJoining) {
        LocalDate doj = LocalDate.parse(dateOfJoining);
        return IDGeneratorUtil.generateInternId(batchId, doj, idType);
    }
}
