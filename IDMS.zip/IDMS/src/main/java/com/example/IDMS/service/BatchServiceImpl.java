package com.example.IDMS.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import com.example.IDMS.dto.BatchDTO;
import com.example.IDMS.dto.InternIdListDTO;
import com.example.IDMS.dto.InternSummaryDTO;
import com.example.IDMS.entity.Batch;
import com.example.IDMS.entity.Intern;
import com.example.IDMS.exception.BatchNotFoundException;
import com.example.IDMS.exception.InternNotFoundException;
import com.example.IDMS.repository.BatchRepository;
import com.example.IDMS.repository.InternRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BatchServiceImpl implements BatchService {

    private final BatchRepository batchRepository;
    private final InternRepository internRepository;

    // 🔹 Helper to map interns
    private List<InternSummaryDTO> mapInterns(List<Intern> interns) {
        return interns != null ? interns.stream()
                .map(intern -> new InternSummaryDTO(
                        intern.getId(),
                        intern.getInternId(),
                        intern.getName(),
                        intern.getEmail(),
                        intern.getDateOfJoining()
                ))
                .collect(Collectors.toList()) : null;
    }

    // 🔹 Helper to calculate endDate
    private LocalDate calculateEndDate(LocalDate startDate) {
        if (startDate == null) return null;
        return startDate.plusMonths(6);
    }

    @Override
    public BatchDTO createBatch(BatchDTO batchDTO) {
        Batch batch = Batch.builder()
                .batchName(batchDTO.getBatchName())
                .startDate(batchDTO.getStartDate())
                .endDate(batchDTO.getEndDate() != null ? batchDTO.getEndDate() : calculateEndDate(batchDTO.getStartDate()))
                .build();

        Batch saved = batchRepository.save(batch);

        return new BatchDTO(
                saved.getId(),
                saved.getBatchName(),
                saved.getStartDate(),
                saved.getEndDate(),
                null
        );
    }

    @Override
    public BatchDTO updateBatch(Long id, BatchDTO batchDTO) {
        Batch batch = batchRepository.findById(id)
                .orElseThrow(() -> new BatchNotFoundException("Batch not found with id " + id));

        batch.setBatchName(batchDTO.getBatchName());
        batch.setStartDate(batchDTO.getStartDate());
        batch.setEndDate(batchDTO.getEndDate() != null ? batchDTO.getEndDate() : calculateEndDate(batchDTO.getStartDate()));

        Batch updated = batchRepository.save(batch);

        return new BatchDTO(
                updated.getId(),
                updated.getBatchName(),
                updated.getStartDate(),
                updated.getEndDate(),
                mapInterns(updated.getInterns())
        );
    }

    @Override
    public void deleteBatch(Long id) {
        if (!batchRepository.existsById(id)) {
            throw new BatchNotFoundException("Batch not found with id " + id);
        }
        batchRepository.deleteById(id);
    }

    @Override
    public List<BatchDTO> getAllBatches() {
        return batchRepository.findAll()
                .stream()
                .map(batch -> {
                    if (batch.getEndDate() == null && batch.getStartDate() != null) {
                        batch.setEndDate(calculateEndDate(batch.getStartDate()));
                    }
                    return new BatchDTO(
                            batch.getId(),
                            batch.getBatchName(),
                            batch.getStartDate(),
                            batch.getEndDate(),
                            mapInterns(batch.getInterns())
                    );
                })
                .collect(Collectors.toList());
    }

    @Override
    public BatchDTO getBatchById(Long id) {
        Batch batch = batchRepository.findById(id)
                .orElseThrow(() -> new BatchNotFoundException("Batch not found with id " + id));

        if (batch.getEndDate() == null && batch.getStartDate() != null) {
            batch.setEndDate(calculateEndDate(batch.getStartDate()));
        }

        return new BatchDTO(
                batch.getId(),
                batch.getBatchName(),
                batch.getStartDate(),
                batch.getEndDate(),
                mapInterns(batch.getInterns())
        );
    }

    @Override
    public BatchDTO assignInternToBatch(Long batchId, Long internId) {
        Batch batch = batchRepository.findById(batchId)
                .orElseThrow(() -> new BatchNotFoundException("Batch not found with id " + batchId));

        Intern intern = internRepository.findById(internId)
                .orElseThrow(() -> new InternNotFoundException("Intern not found with id " + internId));

        intern.setBatch(batch);
        internRepository.save(intern);

        if (batch.getEndDate() == null && batch.getStartDate() != null) {
            batch.setEndDate(calculateEndDate(batch.getStartDate()));
        }

        return new BatchDTO(
                batch.getId(),
                batch.getBatchName(),
                batch.getStartDate(),
                batch.getEndDate(),
                mapInterns(batch.getInterns())
        );
    }

    @Override
    public BatchDTO unassignInternFromBatch(Long batchId, Long internId) {
        Batch batch = batchRepository.findById(batchId)
                .orElseThrow(() -> new BatchNotFoundException("Batch not found with id " + batchId));

        Intern intern = internRepository.findById(internId)
                .orElseThrow(() -> new InternNotFoundException("Intern not found with id " + internId));

        if (intern.getBatch() == null || !intern.getBatch().getId().equals(batchId)) {
            throw new RuntimeException("Intern " + internId + " is not assigned to batch " + batchId);
        }

        intern.setBatch(null);
        internRepository.save(intern);

        if (batch.getEndDate() == null && batch.getStartDate() != null) {
            batch.setEndDate(calculateEndDate(batch.getStartDate()));
        }

        return new BatchDTO(
                batch.getId(),
                batch.getBatchName(),
                batch.getStartDate(),
                batch.getEndDate(),
                mapInterns(batch.getInterns())
        );
    }

    @Override
    public BatchDTO bulkAssignInterns(Long batchId, InternIdListDTO internIds) {
        Batch batch = batchRepository.findById(batchId)
                .orElseThrow(() -> new BatchNotFoundException("Batch not found with id " + batchId));

        internIds.getInternIds().forEach(internId -> {
            Intern intern = internRepository.findById(internId)
                    .orElseThrow(() -> new InternNotFoundException("Intern not found with id " + internId));
            intern.setBatch(batch);
            internRepository.save(intern);
        });

        if (batch.getEndDate() == null && batch.getStartDate() != null) {
            batch.setEndDate(calculateEndDate(batch.getStartDate()));
        }

        return new BatchDTO(
                batch.getId(),
                batch.getBatchName(),
                batch.getStartDate(),
                batch.getEndDate(),
                mapInterns(batch.getInterns())
        );
    }

    @Override
    public BatchDTO bulkUnassignInterns(Long batchId, InternIdListDTO internIds) {
        Batch batch = batchRepository.findById(batchId)
                .orElseThrow(() -> new BatchNotFoundException("Batch not found with id " + batchId));

        internIds.getInternIds().forEach(internId -> {
            Intern intern = internRepository.findById(internId)
                    .orElseThrow(() -> new InternNotFoundException("Intern not found with id " + internId));

            if (intern.getBatch() != null && intern.getBatch().getId().equals(batchId)) {
                intern.setBatch(null);
                internRepository.save(intern);
            }
        });

        if (batch.getEndDate() == null && batch.getStartDate() != null) {
            batch.setEndDate(calculateEndDate(batch.getStartDate()));
        }

        return new BatchDTO(
                batch.getId(),
                batch.getBatchName(),
                batch.getStartDate(),
                batch.getEndDate(),
                mapInterns(batch.getInterns())
        );
    }

    @Override
    public List<Long> getInternIdsInBatch(Long batchId) {
        Batch batch = batchRepository.findById(batchId)
                .orElseThrow(() -> new BatchNotFoundException("Batch not found with id " + batchId));

        return batch.getInterns()
                .stream()
                .map(Intern::getId)
                .collect(Collectors.toList());
    }
}
