package com.example.IDMS.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Intern {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

 // Intern.java
    @Column(name = "id_type", nullable = false)
    private String idType;  // values: "FREE" or "PREMIUM"
    
    @Column(name = "intern_id", nullable = false, unique = true)
    private String internId; // generated ID like 2025-INT001

    private String name;
    private String email;

    private LocalDate dateOfJoining;

    @ManyToOne
    @JoinColumn(name = "batch_id")
    private Batch batch;
}
