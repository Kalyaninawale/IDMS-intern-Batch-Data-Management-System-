package com.example.IDMS.exception;

public class InternNotFoundException extends RuntimeException {
    public InternNotFoundException(String message) {
        super(message);
    }
}
