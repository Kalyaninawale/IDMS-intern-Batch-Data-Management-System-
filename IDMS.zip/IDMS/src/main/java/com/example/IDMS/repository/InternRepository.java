package com.example.IDMS.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.IDMS.entity.Intern;

import java.util.Optional;

public interface InternRepository extends JpaRepository<Intern, Long> {
    Optional<Intern> findByInternId(String internId);
}
