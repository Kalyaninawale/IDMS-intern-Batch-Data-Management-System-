package com.example.IDMS.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

/**
 * Generate sequential Intern IDs per batch and date
 */
public class IDGeneratorUtil {

    // Map to track last sequence per batch+date
    private static final Map<String, Integer> counterMap = new HashMap<>();

    public static synchronized String generateInternId(Long batchId, LocalDate doj, String idType) {
        String datePart = doj.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        String key = batchId + "-" + datePart;

        // Increment sequence per batch+date
        int nextNumber = counterMap.getOrDefault(key, 0) + 1;
        counterMap.put(key, nextNumber);

        String sequence = String.format("%03d", nextNumber);
        return "PREMIUM".equalsIgnoreCase(idType) ? "EMP" + datePart + "-" + sequence
                                                 : "TDA" + datePart + "-" + sequence;
    }
}
