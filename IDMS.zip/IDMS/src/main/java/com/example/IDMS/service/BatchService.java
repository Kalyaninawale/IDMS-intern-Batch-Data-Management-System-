package com.example.IDMS.service;

import java.util.List;

import com.example.IDMS.dto.BatchDTO;
import com.example.IDMS.dto.InternIdListDTO;

public interface BatchService {
    BatchDTO createBatch(BatchDTO batchDTO);
    BatchDTO updateBatch(Long id, BatchDTO batchDTO);
    void deleteBatch(Long id);
    List<BatchDTO> getAllBatches();
    BatchDTO getBatchById(Long id);
    List<Long> getInternIdsInBatch(Long batchId);

    BatchDTO assignInternToBatch(Long batchId, Long internId);

    // 🔹 New method
    BatchDTO unassignInternFromBatch(Long batchId, Long internId);
    

    // 🔹 Bulk operations
    BatchDTO bulkAssignInterns(Long batchId, InternIdListDTO internIds);
    BatchDTO bulkUnassignInterns(Long batchId, InternIdListDTO internIds);
}



