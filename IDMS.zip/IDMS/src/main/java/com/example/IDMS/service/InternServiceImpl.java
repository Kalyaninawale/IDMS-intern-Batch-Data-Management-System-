package com.example.IDMS.service;

import com.example.IDMS.dto.InternDTO;
import com.example.IDMS.dto.InternDetailsDTO;
import com.example.IDMS.entity.Batch;
import com.example.IDMS.entity.Intern;
import com.example.IDMS.repository.BatchRepository;
import com.example.IDMS.repository.InternRepository;
import com.example.IDMS.util.IDGeneratorUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class InternServiceImpl implements InternService {

    private final InternRepository internRepository;
    private final BatchRepository batchRepository;

    @Override
    public InternDTO createIntern(InternDTO internDTO) {
        Intern intern = new Intern();
        intern.setName(internDTO.getName());
        intern.setEmail(internDTO.getEmail());
        intern.setDateOfJoining(internDTO.getDateOfJoining());
        intern.setIdType(internDTO.getIdType());

        if (internDTO.getBatchId() != null) {
            Batch batch = batchRepository.findById(internDTO.getBatchId())
                    .orElseThrow(() -> new RuntimeException("Batch not found"));
            intern.setBatch(batch);

            // 🔹 Generate sequential Intern ID per batch+date
            intern.setInternId(IDGeneratorUtil.generateInternId(batch.getId(), internDTO.getDateOfJoining(), internDTO.getIdType()));
        }

        Intern saved = internRepository.save(intern);
        return mapToDTO(saved);
    }

    @Override
    public List<InternDTO> getAllInterns() {
        return internRepository.findAll().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public InternDTO getInternById(Long id) {
        return mapToDTO(internRepository.findById(id).orElseThrow(() -> new RuntimeException("Intern not found")));
    }

    @Override
    public InternDTO updateIntern(Long id, InternDTO internDTO) {
        Intern intern = internRepository.findById(id).orElseThrow(() -> new RuntimeException("Intern not found"));

        intern.setName(internDTO.getName());
        intern.setEmail(internDTO.getEmail());
        intern.setDateOfJoining(internDTO.getDateOfJoining());
        intern.setIdType(internDTO.getIdType());

        if (internDTO.getBatchId() != null) {
            Batch batch = batchRepository.findById(internDTO.getBatchId())
                    .orElseThrow(() -> new RuntimeException("Batch not found"));
            intern.setBatch(batch);
        }

        Intern updated = internRepository.save(intern);
        return mapToDTO(updated);
    }

    @Override
    public void deleteIntern(Long id) {
        internRepository.deleteById(id);
    }

    @Override
    public InternDetailsDTO getInternDetails(Long id) {
        Intern intern = internRepository.findById(id).orElseThrow(() -> new RuntimeException("Intern not found"));
        InternDetailsDTO dto = new InternDetailsDTO();
        dto.setId(intern.getId());
        dto.setName(intern.getName());
        dto.setEmail(intern.getEmail());
        dto.setInternId(intern.getInternId());
        dto.setDateOfJoining(intern.getDateOfJoining());
        dto.setIdType(intern.getIdType());
        if (intern.getBatch() != null) {
            dto.setBatchId(intern.getBatch().getId());
            dto.setBatchName(intern.getBatch().getBatchName());
        }
        return dto;
    }

    private InternDTO mapToDTO(Intern intern) {
        InternDTO dto = new InternDTO();
        dto.setId(intern.getId());
        dto.setName(intern.getName());
        dto.setEmail(intern.getEmail());
        dto.setInternId(intern.getInternId());
        dto.setDateOfJoining(intern.getDateOfJoining());
        dto.setIdType(intern.getIdType());
        if (intern.getBatch() != null) {
            dto.setBatchId(intern.getBatch().getId());
            dto.setBatchName(intern.getBatch().getBatchName());
        }
        return dto;
    }
}
