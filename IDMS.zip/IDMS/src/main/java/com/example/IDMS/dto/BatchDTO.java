package com.example.IDMS.dto;

import lombok.*;
import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BatchDTO {
	private Long id;
	private String batchName;  // ✅ not "name"
	private LocalDate startDate;
	private LocalDate endDate;


    // 🔹 Now holds full intern details
    private List<InternSummaryDTO> interns;
}
