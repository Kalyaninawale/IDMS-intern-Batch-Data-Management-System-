package com.example.IDMS.dto;

import lombok.*;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InternIdListDTO {
    private List<Long> internIds;
}
