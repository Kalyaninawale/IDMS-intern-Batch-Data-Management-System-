package com.example.IDMS.dto;
import lombok.*;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InternSummaryDTO {
    private Long id;
    private String internId;
    private String name;
    private String email;
    private LocalDate dateOfJoining;
}
