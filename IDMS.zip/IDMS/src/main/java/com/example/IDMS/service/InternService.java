package com.example.IDMS.service;

import com.example.IDMS.dto.InternDTO;
import com.example.IDMS.dto.InternDetailsDTO;

import java.util.List;

public interface InternService {

    /**
     * Create a new intern
     * @param internDTO data to create intern
     * @return created intern with batch details
     */
    InternDTO createIntern(InternDTO internDTO);

    /**
     * Get all interns with their batch name
     * @return list of interns
     */
    List<InternDTO> getAllInterns();

    /**
     * Get intern by ID
     * @param id intern ID
     * @return intern details
     */
    InternDTO getInternById(Long id);

    /**
     * Update intern details by ID
     * @param id intern ID
     * @param internDTO new data
     * @return updated intern with batch details
     */
    InternDTO updateIntern(Long id, InternDTO internDTO);

    /**
     * Delete intern by ID
     * @param id intern ID
     */
    void deleteIntern(Long id);

    /**
     * Get intern with batch + extra details
     * @param id intern ID
     * @return InternDetailsDTO
     */
    InternDetailsDTO getInternDetails(Long id);

}
