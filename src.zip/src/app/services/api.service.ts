// src/app/services/api.service.ts

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Intern {
  id?: number;
  name: string;
  email: string;
  internId?: string;
  dateOfJoining: string;
  idType: string;
  batchId: number;
  batchName?: string;
}

export interface Batch {
  id: number;
  batchName: string;
}

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private baseUrl = 'http://localhost:8080/api';

  constructor(private http: HttpClient) {}

  // ✅ Intern APIs
  getInterns(): Observable<Intern[]> {
    return this.http.get<Intern[]>(`${this.baseUrl}/interns`);
  }

  addIntern(intern: Intern): Observable<Intern> {
    return this.http.post<Intern>(`${this.baseUrl}/interns`, intern);
  }

  updateIntern(intern: Intern): Observable<Intern> {
    return this.http.put<Intern>(`${this.baseUrl}/interns/${intern.id}`, intern);
  }

  deleteIntern(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/interns/${id}`);
  }

  // ✅ Batch APIs
  getBatches(): Observable<Batch[]> {
    return this.http.get<Batch[]>(`${this.baseUrl}/batches`);
  }

  // ✅ Preview ID
  previewInternId(idType: string, dateOfJoining: string): Observable<{ internId: string }> {
    return this.http.get<{ internId: string }>(
      `${this.baseUrl}/interns/preview-id?idType=${idType}&dateOfJoining=${dateOfJoining}`
    );
  }
}
