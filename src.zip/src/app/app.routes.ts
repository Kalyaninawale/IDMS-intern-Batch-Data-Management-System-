import { Routes } from '@angular/router';

// Batch & Intern components
import { BatchListComponent } from './batch/batch-list/batch-list.component';
import { BatchFormComponent } from './batch/batch-form/batch-form.component';
import { InternListComponent } from './intern/intern-list/intern-list.component';
import { InternFormComponent } from './intern/intern-form/intern-form.component';

// Auth
import { LoginComponent } from './auth/login/login.component';
import { AuthGuard } from './auth/auth.guard';

// Dashboards
import { AdminDashboardComponent } from './dashboards/admin-dashboard/admin-dashboard.component';
import { UserDashboardComponent } from './dashboards/user-dashboard/user-dashboard.component';

// Welcome page
import { WelcomeComponent } from './core/welcome/welcome.component';

export const routes: Routes = [
  // Default → login
  { path: '', redirectTo: 'login', pathMatch: 'full' },

  // Auth
  { path: 'login', component: LoginComponent },

  // 🔹 Admin Dashboard with child routes
  {
  path: 'admin',
  component: AdminDashboardComponent,
  canActivate: [AuthGuard],
  children: [
    { path: 'welcome', component: WelcomeComponent },
    { path: 'add-batch', component: BatchFormComponent },
    { path: 'batch-list', component: BatchListComponent },
    { path: 'add-intern', component: InternFormComponent },
    { path: 'intern-list', component: InternListComponent },
    { path: '', redirectTo: 'welcome', pathMatch: 'full' }
  ]
},

  // 🔹 User Dashboard with child routes
 {
  path: 'user',
  component: UserDashboardComponent,
  canActivate: [AuthGuard],
  children: [
    { path: 'welcome', component: WelcomeComponent },
    { path: 'batch-list', component: BatchListComponent },
    { path: 'add-intern', component: InternFormComponent },
    { path: '', redirectTo: 'welcome', pathMatch: 'full' }
  ]
},

  // Wildcard → fallback to login
  { path: '**', redirectTo: 'login' }
];
