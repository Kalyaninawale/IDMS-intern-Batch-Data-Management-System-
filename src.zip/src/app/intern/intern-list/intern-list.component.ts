import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { ApiService, Intern } from '../../services/api.service';
import { InternEditDialogComponent } from '../intern-edit-dialog/intern-edit-dialog.component';

@Component({
  selector: 'app-intern-list',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatButtonModule,
    MatDialogModule
  ],
  templateUrl: './intern-list.component.html',
  styleUrls: ['./intern-list.component.css']
})
export class InternListComponent implements OnInit {

  displayedColumns: string[] = [
    'id', 
    'name', 
    'email', 
    'batchName', 
    'idType', 
    'dateOfJoining', 
    'actions'
  ];

  interns: Intern[] = [];

  constructor(private apiService: ApiService, private dialog: MatDialog) {}

  ngOnInit(): void {
    this.loadInterns();
  }

  // Fetch interns from backend
  loadInterns() {
    this.apiService.getInterns().subscribe({
      next: (data: Intern[]) => {
        this.interns = data;
      },
      error: (err) => {
        console.error('Error fetching interns:', err);
      }
    });
  }

  // Delete intern
  deleteIntern(id: number) {
    if (confirm('Are you sure you want to delete this intern?')) {
      this.apiService.deleteIntern(id).subscribe({
        next: () => {
          this.interns = this.interns.filter((i) => i.id !== id);
        },
        error: (err) => {
          console.error('Error deleting intern:', err);
        }
      });
    }
  }

  // Edit intern
  editIntern(intern: Intern) {
    const dialogRef = this.dialog.open(InternEditDialogComponent, {
      width: '400px',
      data: { ...intern }
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        const updatedIntern = { ...intern, ...result };
        this.apiService.updateIntern(updatedIntern).subscribe({
          next: () => {
            const index = this.interns.findIndex((i) => i.id === intern.id);
            if (index !== -1) {
              this.interns[index] = updatedIntern;
            }
          },
          error: (err) => {
            console.error('Error updating intern:', err);
          }
        });
      }
    });
  }
}
