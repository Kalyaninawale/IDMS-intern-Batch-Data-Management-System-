import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ApiService, Intern, Batch } from '../../services/api.service';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-intern-form',
  standalone: true,
  templateUrl: './intern-form.component.html',
  styleUrls: ['./intern-form.component.css'],
  imports: [CommonModule, ReactiveFormsModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule]
})
export class InternFormComponent implements OnInit {
  internForm: FormGroup;
  batches: Batch[] = [];
  idTypes: string[] = ['FREE', 'PREMIUM'];
 generatedInternId: string | null | undefined = null;

  constructor(private fb: FormBuilder, private apiService: ApiService) {
    this.internForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      dateOfJoining: ['', Validators.required],
      idType: ['FREE', Validators.required],
      batchId: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.loadBatches();
    this.internForm.get('dateOfJoining')?.valueChanges.subscribe(() => this.previewInternId());
    this.internForm.get('idType')?.valueChanges.subscribe(() => this.previewInternId());
    this.internForm.get('batchId')?.valueChanges.subscribe(() => this.previewInternId());
  }

  loadBatches(): void {
    this.apiService.getBatches().subscribe({
      next: data => this.batches = data,
      error: err => console.error('Error fetching batches:', err)
    });
  }

  previewInternId(): void {
    const formValue = this.internForm.value;
    if (formValue.dateOfJoining && formValue.idType && formValue.batchId) {
      this.apiService.previewInternId(formValue.idType, formValue.dateOfJoining)
        .subscribe({
          next: res => this.generatedInternId = res?.internId ?? null,
          error: err => console.error('Error fetching preview ID:', err)
        });
    }
  }

  onSubmit(): void {
    if (this.internForm.valid) {
      const intern: Intern = this.internForm.value;
      this.apiService.addIntern(intern).subscribe({
        next: res => {
          this.generatedInternId = res.internId;
          alert(`Intern added successfully! Generated ID: ${res.internId}`);
          this.internForm.reset({ idType: 'FREE' });
        },
        error: err => console.error('Error saving intern:', err)
      });
    }
  }
}
