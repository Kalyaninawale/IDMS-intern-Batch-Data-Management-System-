import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { Intern } from '../../services/api.service';

@Component({
  selector: 'app-intern-edit-dialog',
  standalone: true,
  templateUrl: './intern-edit-dialog.component.html',
  styleUrls: ['./intern-edit-dialog.component.css'],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule
  ]
})
export class InternEditDialogComponent {
  internForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<InternEditDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: Intern
  ) {
    this.internForm = this.fb.group({
      name: [data.name, Validators.required],
      email: [data.email, [Validators.required, Validators.email]],
      batchId: [data.batchId, Validators.required]
    });
  }

  onSave() {
    if (this.internForm.valid) {
      this.dialogRef.close(this.internForm.value); // Pass updated data back
    }
  }

  onCancel() {
    this.dialogRef.close(null);
  }
}
