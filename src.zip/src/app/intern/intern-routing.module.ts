// src/app/intern/intern-routing.module.ts
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { InternListComponent } from './intern-list/intern-list.component';
import { InternFormComponent } from './intern-form/intern-form.component';

const routes: Routes = [
  { path: '', component: InternListComponent },   // /interns
  { path: 'add', component: InternFormComponent } // /interns/add
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InternRoutingModule {}
