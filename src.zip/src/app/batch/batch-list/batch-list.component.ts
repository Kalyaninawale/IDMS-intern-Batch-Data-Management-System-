// src/app/batch/batch-list/batch-list.component.ts
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { BatchService, Batch, Intern } from '../services/batch.service';

@Component({
  selector: 'app-batch-list',
  standalone: true,
  imports: [CommonModule, MatTableModule, MatButtonModule],
  templateUrl: './batch-list.component.html',
  styleUrls: ['./batch-list.component.css']
})
export class BatchListComponent implements OnInit {

  batches: Batch[] = [];
  selectedStudents: Intern[] = []; // store students of selected batch
  selectedBatchName: string = '';   // show batch name above student list
  displayedColumns: string[] = ['id', 'batchName', 'startDate', 'endDate', 'actions'];

  constructor(private batchService: BatchService) {}

  ngOnInit(): void {
    this.loadBatches();
  }

  // ✅ Load all batches
  loadBatches(): void {
    this.batchService.getAllBatches().subscribe({
      next: (data: Batch[]) => {
        this.batches = data;
      },
      error: (err: any) => {
        console.error('❌ Error loading batches', err);
      }
    });
  }

  // ✅ Delete batch
  deleteBatch(id: number): void {
    if (confirm('Are you sure you want to delete this batch?')) {
      this.batchService.deleteBatch(id).subscribe({
        next: () => {
          this.batches = this.batches.filter(b => b.id !== id);
          console.log(`✅ Batch ${id} deleted`);
          // Clear selected students if deleted batch was selected
          if (this.selectedStudents.length && this.selectedBatchName === this.getBatchNameById(id)) {
            this.selectedStudents = [];
            this.selectedBatchName = '';
          }
        },
        error: (err) => console.error('❌ Error deleting batch', err)
      });
    }
  }

  // ✅ View students for selected batch
  viewStudents(batchId: number): void {
    this.batchService.getBatchById(batchId).subscribe({
      next: (batch: Batch) => {
        this.selectedStudents = batch.interns || [];
        this.selectedBatchName = batch.batchName;
      },
      error: (err) => {
        console.error('❌ Error fetching students', err);
      }
    });
  }

  // ✅ Helper: get batch name by ID
  private getBatchNameById(batchId: number): string {
    const batch = this.batches.find(b => b.id === batchId);
    return batch ? batch.batchName : '';
  }
}
