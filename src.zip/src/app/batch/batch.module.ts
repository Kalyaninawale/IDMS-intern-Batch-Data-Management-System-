import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

// Angular Material
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';

// Components (standalone)
import { BatchFormComponent } from '../batch/batch-form/batch-form.component';
import { BatchListComponent } from './batch-list/batch-list.component';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatTableModule,
    MatButtonModule,
    BatchFormComponent,   // ✅ import standalone
    BatchListComponent    // ✅ import standalone
  ],
  exports: [
    BatchFormComponent,   // ✅ now valid
    BatchListComponent    // ✅ now valid
  ]
})
export class BatchModule {}
