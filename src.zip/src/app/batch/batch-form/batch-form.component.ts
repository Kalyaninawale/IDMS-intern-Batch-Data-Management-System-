import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { BatchService } from '../services/batch.service';

@Component({
  selector: 'app-batch-form',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSnackBarModule
  ],
  templateUrl: './batch-form.component.html',
  styleUrls: ['../../../styles.css']
})
export class BatchFormComponent {
  batchForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private batchService: BatchService,
    private snackBar: MatSnackBar
  ) {
    this.batchForm = this.fb.group({
      batchName: ['', Validators.required],
      startDate: ['', Validators.required],
      endDate: [{ value: '', disabled: true }, Validators.required] // disabled so user can’t edit
    });

    // 👇 Auto-calculate endDate (6 months after startDate)
    this.batchForm.get('startDate')?.valueChanges.subscribe((startDate: string) => {
      if (startDate) {
        const start = new Date(startDate);
        const end = new Date(start);
        end.setMonth(start.getMonth() + 6);

        this.batchForm.get('endDate')?.setValue(
          end.toISOString().split('T')[0], 
          { emitEvent: false }
        );
      } else {
        this.batchForm.get('endDate')?.reset();
      }
    });
  }

  onSubmit() {
    if (this.batchForm.valid) {
      const rawData = this.batchForm.getRawValue();

      // ✅ format dates as yyyy-MM-dd
      const formatDate = (dateStr: string) => {
        const d = new Date(dateStr);
        return d.toISOString().split('T')[0];
      };

      const batchData = {
        batchName: rawData.batchName,
        startDate: formatDate(rawData.startDate),
        endDate: formatDate(rawData.endDate)
      };

      this.batchService.createBatch(batchData).subscribe({
        next: (response) => {
          console.log('✅ Batch saved successfully:', response);

          this.snackBar.open('Batch added successfully!', 'Close', {
            duration: 3000,
            panelClass: ['success-snackbar']
          });

          this.batchForm.reset();
        },
        error: (err) => {
          console.error('❌ Error saving batch:', err);

          this.snackBar.open('Failed to add batch. Please try again.', 'Close', {
            duration: 3000,
            panelClass: ['error-snackbar']
          });
        }
      });
    }
  }
}
