// src/app/batch/services/batch.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

// ✅ Define Intern interface
export interface Intern {
  id?: number;
  internId: string;
  name: string;
  email: string;
  dateOfJoining: string;
}

// ✅ Updated Batch interface to include interns
export interface Batch {
  id?: number;          // optional, backend generates
  batchName: string;
  startDate: string;
  endDate: string;
  interns?: Intern[];   // optional, returned by backend
}

@Injectable({
  providedIn: 'root'
})
export class BatchService {
  private apiUrl = 'http://localhost:8080/api/batches';

  constructor(private http: HttpClient) {}

  // ✅ Helper: get headers with JWT
  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token'); // make sure this key matches your login storage
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': token ? `Bearer ${token}` : ''
    });
  }

  // ✅ Get all batches with interns
  getAllBatches(): Observable<Batch[]> {
    return this.http.get<Batch[]>(this.apiUrl, { headers: this.getAuthHeaders() });
  }

  // ✅ Get single batch by ID (to view students)
  getBatchById(id: number): Observable<Batch> {
    return this.http.get<Batch>(`${this.apiUrl}/${id}`, { headers: this.getAuthHeaders() });
  }

  createBatch(batch: Batch): Observable<Batch> {
    return this.http.post<Batch>(this.apiUrl, batch, { headers: this.getAuthHeaders() });
  }

  updateBatch(id: number, batch: Batch): Observable<Batch> {
    return this.http.put<Batch>(`${this.apiUrl}/${id}`, batch, { headers: this.getAuthHeaders() });
  }

  deleteBatch(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`, { headers: this.getAuthHeaders() });
  }
}
