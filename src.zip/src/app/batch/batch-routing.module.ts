// src/app/batch/batch-routing.module.ts
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BatchListComponent } from './batch-list/batch-list.component';
import { BatchFormComponent } from './batch-form/batch-form.component';

const routes: Routes = [
  { path: '', component: BatchListComponent },   // /batches
  { path: 'add', component: BatchFormComponent } // /batches/add
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BatchRoutingModule {}
