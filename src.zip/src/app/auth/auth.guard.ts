// src/app/auth/auth.guard.ts
import { Injectable } from '@angular/core';
import { CanActivate, Router, UrlTree, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from './auth.service';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | UrlTree {
    // 🔹 Check if running in browser and user is logged in
    if (typeof window === 'undefined' || !this.authService.isLoggedIn()) {
      return this.router.parseUrl('/login');
    }

    let role = this.authService.getRole();

    // 🔹 If role is missing, redirect to login
    if (!role) {
      return this.router.parseUrl('/login');
    }

    // 🔹 Normalize role to uppercase to match checks
    const roleNormalized = role.toUpperCase();

    // 🔹 Optional debug logging
    console.log('AuthGuard check → URL:', state.url, 'Role:', roleNormalized);

    // 🔹 Admin routes
    if (state.url.startsWith('/admin') && roleNormalized !== 'ADMIN') {
      return this.router.parseUrl('/user'); // redirect user to correct dashboard
    }

    // 🔹 User routes
    if (state.url.startsWith('/user') && roleNormalized !== 'USER') {
      return this.router.parseUrl('/admin'); // redirect admin to admin dashboard
    }

    return true; // allow access
  }
}
