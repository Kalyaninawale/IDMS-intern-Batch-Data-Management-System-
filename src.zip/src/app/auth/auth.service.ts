// src/app/auth/auth.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private apiUrl = 'http://localhost:8080/auth';
  private tokenKey = 'jwtToken';
  private roleKey = 'userRole';

  constructor(private http: HttpClient) {}

  // Login → returns token string
  login(username: string, password: string): Observable<string> {
    return this.http.post(this.apiUrl + '/login', { username, password }, { responseType: 'text' });
  }

  // Save token + decode role
  saveToken(token: string) {
    if (typeof window !== 'undefined') {
      localStorage.setItem(this.tokenKey, token);
      const payload = JSON.parse(atob(token.split('.')[1]));
      localStorage.setItem(this.roleKey, payload.role);
    }
  }

  // Get token
  getToken(): string | null {
    if (typeof window === 'undefined') return null;
    return localStorage.getItem(this.tokenKey);
  }

  // Get role
  getRole(): string | null {
    if (typeof window === 'undefined') return null;
    return localStorage.getItem(this.roleKey);
  }

  // Check if logged in
  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  // Logout
  logout() {
    if (typeof window !== 'undefined') {
      localStorage.removeItem(this.tokenKey);
      localStorage.removeItem(this.roleKey);
    }
  }
}
